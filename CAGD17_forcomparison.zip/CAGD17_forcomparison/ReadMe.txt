Here are two zipped files, which include results tested by our CAGD work entitled ��Robust Mesh Denoising via Vertex Pre-filtering and L1-Median Normal Filtering��. The inputs are provided by other researchers, who requested to compare with our technique. We also embed our parameters for each test (refer to our paper).

The results are immediately ready for your comparisons with this paper. Please feel free to use them:)  Also, please cite our work as follows:

@article{LU2017,
title = "Robust mesh denoising via vertex pre-filtering and L1-median normal filtering",
journal = "Computer Aided Geometric Design",
volume = "54",
number = "Supplement C",
pages = "49 - 60",
year = "2017",
issn = "0167-8396",
doi = "https://doi.org/10.1016/j.cagd.2017.02.011",
url = "http://www.sciencedirect.com/science/article/pii/S0167839617300638",
author = "Xuequan Lu and Wenzhi Chen and Scott Schaefer",
keywords = "Mesh denoising, Feature preserving, Vertex pre-filtering, -median normal filtering"
}